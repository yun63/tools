python conf/conf.py ./conf/master.template $@


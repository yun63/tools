#! /bin/bash

checknum=6380
redisdir='/usr/local/redis'

#while [[ $checknum -lt 6315 ]];do
#    rm -rf ${redisdir}/conf/${checknum}.conf
#    cp ${redisdir}/conf/8000.conf $redisdir/conf/${checknum}.conf
#    sed -i "s/8000/${checknum}/g" $redisdir/conf/${checknum}.conf
#    echo "/usr/local/redis/bin/redis-server /usr/local/redis/conf/${checknum}.conf &" >> $redisdir/shell/start_new.sh
#    let checknum=checknum+1
#done

while [[ $checknum -lt 6388 ]];do
    rm -rf ${redisdir}/conf/${checknum}.conf
    cp ${redisdir}/conf/8000.conf $redisdir/conf/${checknum}.conf
    sed -i "s/8000/${checknum}/g" $redisdir/conf/${checknum}.conf
    echo "/usr/local/redis/bin/redis-server /usr/local/redis/conf/${checknum}.conf &" >> $redisdir/shell/start_new.sh
    let checknum=checknum+1
done

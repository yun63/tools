echo "config set tuyoo-check-chip-modify-enable $1" | redis-cli -p 6380
echo "config set tuyoo-check-chip-modify-enable $1" | redis-cli -p 6381
echo "config set tuyoo-check-chip-modify-enable $1" | redis-cli -p 6382
echo "config set tuyoo-check-chip-modify-enable $1" | redis-cli -p 6383
echo "config set tuyoo-check-chip-modify-enable $1" | redis-cli -p 6384
echo "config set tuyoo-check-chip-modify-enable $1" | redis-cli -p 6385
echo "config set tuyoo-check-chip-modify-enable $1" | redis-cli -p 6386
echo "config set tuyoo-check-chip-modify-enable $1" | redis-cli -p 6387

#echo "config set tuyoo-cmd-sendudp-enable $1" | redis-cli -p 6380
#echo "config set tuyoo-cmd-sendudp-enable $1" | redis-cli -p 6381
#echo "config set tuyoo-cmd-sendudp-enable $1" | redis-cli -p 6382
#echo "config set tuyoo-cmd-sendudp-enable $1" | redis-cli -p 6383
#echo "config set tuyoo-cmd-sendudp-enable $1" | redis-cli -p 6384
#echo "config set tuyoo-cmd-sendudp-enable $1" | redis-cli -p 6385
#echo "config set tuyoo-cmd-sendudp-enable $1" | redis-cli -p 6386
#echo "config set tuyoo-cmd-sendudp-enable $1" | redis-cli -p 6387

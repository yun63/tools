#!/bin/bash

#CONT=0
#while true
#do
#       idx=$((CONT%8))
#       idx=$((idx+6380))
#       echo "bgsave" | redis-cli -p $idx
#       echo $DSTR" send bgsave to redis_port="$idx >> /usr/local/redis/crondate.log
#       CONT=$(($CONT + 1))
#       sleep 5m
#done

port_list="6380 6381 6382 6383 6384 6385 6385 6386 6387 6377 6337 6501"
port_tuyoo_list="6377 6379 6400 6401 6402 6403 6404 6405 6406 6407 6408 6410 6411 6500 6501"

while :
do
   for port in $port_list
   do
     #echo "$port"
     DSTR=`date`
     echo "bgsave" | /usr/local/redis/bin/redis-cli -p $port
     echo $DSTR" send bgsave to redis_port="$port >> /usr/local/redis/crondate.log
     sleep 1m
   done
   
   for port_tuyoo in $port_tuyoo_list
   do 
     #echo "$port"
     DSTR=`date`
     echo "bgsave-tuyoo" | /usr/local/redis/bin/redis-cli -p $port_tuyoo
     echo $DSTR" send bgsave to redis_port="$port_tuyoo >> /usr/local/redis/crondate.log
     sleep 1m
   done 
done

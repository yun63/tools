/usr/local/redis/bin/redis-server /usr/local/redis/conf/6337-slave.conf &

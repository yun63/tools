<!DOCTYPE html>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<html>
<head><link rel="shortcut icon" href="favicon.png"/></head>
<title>Android 版本发布</title>
<style>
div {
    float:left;
}

#CmdResult {
    float:left;
    height: 600px;
    width: 1024px;
    border: 1px solid #EDEDED;
    padding-left: 5px;
    overflow: auto;
}
</style>
<body>
	<div> 
		<input type="button" value="获取权限" id="auth"/> 
        <label id="echo"></label>
        &nbsp;&nbsp;&nbsp;
		<label id="uidir">UI文件夹</label> 
		<input id="ui"></input> 
    </div>
    <p>&nbsp;</p>
    <div id="cmd">
        <input type = "button" id = "uisync"  value = "UI资源发布(仅美术用)"/>
        <input type = "button" id = "announce"  value = "公告发布(长江专用)"/>
        <!--<input type = "button" id = "uipublish"  value = "UI发布(仅美术用)"/> -->
        <!--<input type = "button" id = "diff"    value = "资源差异"/> -->
        <input type = "button" id = "lua"     value = "同步代码"/>
        <input type = "button" id = "src"     value = "同步代码(含程序资源)"/>
        <input type = "button" id = "res"     value = "同步原始资源"/>
        <input type = "button" id = "pack"    value = "打包资源"/>
        <input type = "button" id = "scene"   value = "生成场景"/>
        <input type = "button" id = "config"  value = "生成数据"/>
        <input type = "button" id = "publish" value = "发布更新"/>
    </div>
    <p>&nbsp;</p>
    <div id="CmdResult"></div>
    <!--
    <script src="http://code.jquery.com/jquery-1.10.0.min.js" type="text/javascript"></script>
    <script src="http://keleyi.com/keleyi/pmedia/jquery/ui/1.10.3/js/jquery-ui-1.10.3.min.js" type="text/javascript"></script>
    -->
    <script src="jquery-1.10.0.min.js" type="text/javascript"></script>
    <script src="jquery-ui-1.10.3.min.js" type="text/javascript"></script>
    <script src="jquery.blockUI.js" type="text/javascript"></script>
    <script type="text/javascript">
$(document).ready(function() {
    //消息Id
    //1 获取权限
    //2 释放权限
    if ("WebSocket" in window)
    {
        //var ws = new WebSocket("ws://192.168.1.118:8017");
        var ws = new WebSocket("ws://192.168.1.90:8017");
        ws.onopen = function() {
            $("#echo").html("服务器连接成功!尚未获取权限");
        };

        ws.onmessage = function (evt) {
            var data = JSON.parse(evt.data);
            var cmd = data[0];
            var cmdCode = data[1];
            var cmdText = data[2];
            console.log(cmd, " result:", cmdCode);
            //获取权限
            if(cmd == 1)
            {
                if(cmdCode == 0)
                {
                    $("#echo").html("成功获取权限");
                    $("#auth").val("释放权限");
                }
                else
                {
                    //$("#echo").html("当前有人在使用,请吼一嗓子!");
                    $("#echo").html(cmdText);
                }
            }
            //释放权限
            else if(cmd == 2)
            {
                $("#echo").html("服务器连接成功!尚未获取权限");
                $("#auth").val("获取权限");
            }
            //比较差异
            else if(cmd == 3)
            {   
                $.unblockUI();
                $("#CmdResult").html(cmdText);
            }
            //同步代码
            else if(cmd == 4)
            {   
                $.unblockUI();
                $("#CmdResult").html(cmdText);
            }
            //同步资源
            else if(cmd == 5)
            {   
                $.unblockUI();
                $("#CmdResult").html(cmdText);
            }
            //打包资源
            else if(cmd == 6)
            {   
                $.unblockUI();
                $("#CmdResult").html(cmdText);
            }
            //生成场景
            else if(cmd == 7)
            {   
                $.unblockUI();
                $("#CmdResult").html(cmdText);
            }
            //生成配置
            else if(cmd == 8)
            {   
                $.unblockUI();
                $("#CmdResult").html(cmdText);
            }
            //发布更新
            else if(cmd == 9)
            {   
                $.unblockUI();
                $("#CmdResult").html(cmdText);
            }
            //美术发布资源
            else if(cmd == 10)
            {   
                $.unblockUI();
                $("#CmdResult").html(cmdText);
            }
        };

        ws.onclose = function() {
            $("#echo").html("服务器连接失败,请刷新!!");
        };

        $("#auth").click(function() {
            if($("#auth").val() == "获取权限")
            {
                var val = JSON.stringify([1]);
                ws.send(val);
            }
            else
            {
                var val = JSON.stringify([2]);
                ws.send(val);
            }
        });

        $("#diff").click(function() {
            var val = JSON.stringify([3]);
            ws.send(val);
            $.blockUI();
        });

        $("#lua").click(function() {
            var val = JSON.stringify([13]);
            ws.send(val);
            $.blockUI();
        });

        $("#announce").click(function() {
            var val = JSON.stringify([15]);
            ws.send(val);
            $.blockUI();
        });

        $("#src").click(function() {
            var val = JSON.stringify([4]);
            ws.send(val);
            $.blockUI();
        });

        $("#res").click(function() {
            var val = JSON.stringify([5]);
            ws.send(val);
            $.blockUI();
        });

        $("#pack").click(function() {
            var val = JSON.stringify([6]);
            ws.send(val);
            $.blockUI();
        });

        $("#scene").click(function() {
            var val = JSON.stringify([7]);
            ws.send(val);
            $.blockUI();
        });

        $("#config").click(function() {
            var val = JSON.stringify([8]);
            ws.send(val);
            $.blockUI();
        });

        $("#publish").click(function() {
            var val = JSON.stringify([9]);
            ws.send(val);
            $.blockUI();
        });

        $("#uisync").click(function() {
            var val = JSON.stringify([10]);
            ws.send(val);
            $.blockUI();
        });

        $("#uipublish").click(function() {
            var uidir = $("#ui").val();
            if(uidir == "")
            {
                alert("UI文件夹不能为空");
                return;
            }
            var val = JSON.stringify([11, uidir]);
            ws.send(val);
            $.blockUI();
        });

        $("#sceneres").click(function() {
            var val = JSON.stringify([12]);
            ws.send(val);
            $.blockUI();
        });
    }
    else 
    {
        $("#echo").html("浏览器不支持websocket!");
    };
});
</script>
</body>
</html>

<?php
include("ver.php");
include("info_ver.php");

function do_res_response($package, $size) {
    global $current_version;
    return "Resource $current_version http://192.168.1.90/mobpkg/$package $size";
}

function get_res_package($old_version, $new_version) {
    global $packages;
    $package = "${old_version}_${new_version}.zip";
    $size = $packages[$package];
    return do_res_response($package, $size);
}

function get_info_package($key) {
    global $server_info_package;
    global $server_info_package_size;
    return "ServerInfo $key http://192.168.1.90/mobinfo/$server_info_package $server_info_package_size"; 
}

$user_version = $_GET["ver"];
$user_key = $_GET["key"];

if ($user_version < $base_version) {
    echo "wrongrelease";
}
elseif ($user_version > $current_version) {
    echo "wrongrelease";
}
elseif ($user_version == $current_version) {
    global $server_info_key;
    if($user_key != $server_info_key) {
        echo get_info_package($server_info_key);
    }
    else {
        echo "noupdate";
    }
}
else {
    if ($current_version - $user_version < $package_number) {
        echo get_res_package($user_version, $current_version);
    }
    else {
        if ($user_version > $current_version - $package_number) {
            echo get_res_package($user_version, $current_version);
        }
        else {
            echo get_res_package($base_version, $current_version);
        }
    }
}
?>

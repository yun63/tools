<?php
$server_info_key = "3ab09a13ca02e18bb878ac520b66954e"; 
$server_info_package = "3ab09a13ca02e18bb878ac520b66954e.zip";
$server_info_package_size = 0.00937748;
?>

#! /bin/bash
PASS=/data/mobile/resource_publish/.rsync.pass
SYNC_PATH=rsync://rsy_user@192.168.1.90
DEST_PATH=/data/mobile/resource_publish/rawres

rsync -azvp --delete --password-file=${PASS}  ${SYNC_PATH}/resource ${DEST_PATH}/resource
rsync -azvp --delete --password-file=${PASS}  ${SYNC_PATH}/resource_data ${DEST_PATH}/resource_data



echo "同步原始图片资源成功 (*^__^*) "

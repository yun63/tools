#! /bin/bash
SVN_U=mengyue_client_read
SVN_P=`cat /data/save/svn_p`
CONFIG_PATH=/data/web/mobver/
PKG_PATH=/data/web/mobpkg/

PACK_HOST=xs-cdn:/data/web/xs_viewer/devpkg/
VER_HOST=xs-ver:/data/web/mskd/server/

#svn options
OPTS="--username ${SVN_U} --password ${SVN_P} --no-auth-cache --non-interactive"

svn_up() {
    svn ${OPTS} up
}

svn_add() {
    file=$1
    svn ${OPTS} add $file 
}

svn_delete() {
    file=$1
    svn ${OPTS} delete $file 
}

svn_ci() {
    svn ${OPTS} ci -m "提交资源"
}


# 将数据提交到svn中
commit_to_svn() {
    echo "提交资源到svn中..."
    svn status |\
    while read line; do
        if [ ${line:0:1} = "?" ]; then
            part=`echo $line | cut -d' ' -f 2-`
            file=${part/ /}
            if [ "$file" != "escript" ]  && [ "$file" != "packages" ] && [ "$file" != "jitscript" ]; then
               #echo ${file}
               svn_add $file
            fi
        fi
    done
    if ! svn_ci; then
        error "提交资源到svn失败"
    fi
    echo "提交svn成功 ^_^"
    svn_up
}

## 这句话主要为了防止产生空的更新包
echo `date` > /data/mobile/resource_publish/publish/res/gui/tmpver

cd /data/mobile/resource_publish/publish
## 版本号递增
python config.py
## 资源打包
python version.py

commit_to_svn


##同步package 到资源服务器
rsync -azvp --delete packages/ ${PKG_PATH}/
##拷贝ver.php 到版本服务器
cp ver.php ${CONFIG_PATH}
##外网服务器
scp packages/*.zip $PACK_HOST 
scp ver.php $VER_HOST

echo "发布版本成功 (*^__^*) "

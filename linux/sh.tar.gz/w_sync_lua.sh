#! /bin/bash
SVN_URL=http://192.168.1.105/svn/mobile-resource-publish/
SVN_U=mengyue_client_read
SVN_P=`cat /data/mobile/resource_publish/.svn.pass`
PUBLISH_DIR=/data/mobile/resource_publish/publish
RES_TO=${PUBLISH_DIR}/res
SCRIPT_TO=${PUBLISH_DIR}/res/script

# 资源封版的资源路径
RES_DIR="/data/mobile/resource_publish/Resources"
SCRIPT_DIR="/data/mobile/resource_publish/Resources/script"

OLDPWD=$(cd "$(dirname "${0}")"; pwd)


#svn options
OPTS="--username ${SVN_U} --password ${SVN_P} --no-auth-cache --non-interactive"

error() {
    echo $1
    exit 1
}

svn_up() {
    svn ${OPTS} up
}

svn_add() {
    file=$1
    svn ${OPTS} add $file 
}

svn_delete() {
    file=$1
    svn ${OPTS} delete $file 
}

svn_ci() {
    svn ${OPTS} ci -m "提交代码"
}


## 将封版资源更新到本地
dev_up() {
    echo "================================"
    echo "正在更新脚本到本地..." 
    cd ${SCRIPT_DIR} 
    svn_up 
    cd ${OLDPWD}

    cd ${RES_DIR}
    svn_up
    cd ${OLDPWD}
}

# 将数据同步到flash-release文件
sync_to_publish() {
    echo "================================"
    echo "rsync 执行同步..."
    line=`rsync -avpt --exclude ".svn" --delete $SCRIPT_DIR/. $SCRIPT_TO |grep non-empty  |awk -F: '{print $2}' |sort -n`

    if [ -z "$line" ];then
            echo "代码同步完成,没有进行目录删除操作"
        else
            for i in $line
            do 
                rm -r ${RES_TO}/${i} >/dev/null 2>&1
                echo "删除了以下目录：$i"
            done
        echo "代码同步完成 "
    fi
    echo "================================"
}

# 将数据提交到svn中
commit_to_svn() {
    echo "提交代码到svn中..."
    cd ${PUBLISH_DIR}
    svn status | \
    while read line; do
        if [ ${line:0:1} = "?" ]; then
            part=`echo $line | cut -d' ' -f 2-`
            file=${part/ /}
            if [ "$file" != "escript" ]  && [ "$file" != "packages" ] && [ "$file" != "jitscript" ]; then
               #echo ${file}
               svn_add $file
            fi
        fi
    done

    svn status | 
    while read line; do
        if [ ${line:0:1} = "!" ]; then
            part=`echo $line | cut -d' ' -f 2-`
            file=${part/ /}
            svn_delete $file
        fi
    done
    
    if ! svn_ci; then
        error "提交代码到svn失败"
    fi
    svn_up
    echo "代码变化成功提交svn ^_^"
    echo "================================"
}

dev_up
sync_to_publish
commit_to_svn

echo "同步最新代码成功 (*^__^*)"

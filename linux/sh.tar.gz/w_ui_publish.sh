#! /bin/bash
SVN_U=mengyue_client_read
SVN_P=`cat /data/save/svn_p`
OPTS="--username ${SVN_U} --password ${SVN_P} --no-auth-cache --non-interactive"

LUA_UI_DEST=/data/mobile/resource_publish/publish/res/script/config/uicfg
DEV_LUA_UI_DEST=/data/mobile/resource_publish/Resources/script/config/uicfg

svn_up() {
    svn ${OPTS} up
}

svn_add() {
    file=$1
    svn ${OPTS} add $file 
}

svn_delete() {
    file=$1
    svn ${OPTS} delete $file 
}

svn_ci() {
    svn ${OPTS} ci -m "提交资源"
}


# 将数据提交到svn中
commit_to_svn() {
    echo "提交资源到svn中..."
    svn status |\
    while read line; do
        if [ ${line:0:1} = "?" ]; then
            part=`echo $line | cut -d' ' -f 2-`
            file=${part/ /}
            if [ "$file" != "escript" ]  && [ "$file" != "packages" ] && [ "$file" != "jitscript" ]; then
               #echo ${file}
               svn_add $file
            fi
        fi
    done
    if ! svn_ci; then
        error "提交资源到svn失败"
    fi
    echo "提交svn成功 ^_^"
    svn_up
}


cd /data/mobile/resource_publish/rawres/genuicfg/svn_ui
svn_up

if [ -n "$1" ]
then
    #生成lua
    cd /data/mobile/resource_publish/rawres/genuicfg/
    mkdir -p lua_ui && rm ./lua_ui/*.lua
    ./autogen2.sh $1
    #将新生成的UI文件拷贝到svn目录
    cp /data/mobile/resource_publish/rawres/genuicfg/lua_ui/*.lua $LUA_UI_DEST 
    # 同步到程序的svn
    cp /data/mobile/resource_publish/rawres/genuicfg/lua_ui/*.lua $DEV_LUA_UI_DEST
    cd $DEV_LUA_UI_DEST && svn_up
    cd $DEV_LUA_UI_DEST && commit_to_svn    
    #发布新版本
    cd /data/mobile/resource_publish && ./w_publish.sh
    exit 0
fi

echo "亲，没有指定文件夹..."

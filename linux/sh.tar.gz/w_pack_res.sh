#! /bin/bash
SVN_U=mengyue_client_read
SVN_P=`cat /data/mobile/resource_publish/.svn.pass`
OPTS="--username ${SVN_U} --password ${SVN_P} --no-auth-cache --non-interactive"


cd /data/mobile/resource_publish/rawres/texturepacker
svn ${OPTS} up

./auto_gen.erl
./pic_gen.erl


cd /data/mobile/resource_publish/rawres/resource
cp -rf audio /data/mobile/resource_publish/publish/res/
cp -rf font /data/mobile/resource_publish/publish/res/


echo "打包资源成功 (*^__^*) "

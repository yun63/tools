#! /bin/bash
SVN_U=mengyue_client_read
SVN_P=`cat /data/mobile/resource_publish/.svn.pass`
OPTS="--username ${SVN_U} --password ${SVN_P} --no-auth-cache --non-interactive"

cd /data/mobile/resource_publish/rawres/gensysdata

svn ${OPTS} up
#make data
make dd

cp -rf data/* /data/mobile/resource_publish/publish/res/script/config/

echo "生成配置数据成功 (*^__^*) "

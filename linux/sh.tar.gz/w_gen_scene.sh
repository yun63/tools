#! /bin/bash
SVN_U=mengyue_client_read
SVN_P=`cat /data/mobile/resource_publish/.svn.pass`
OPTS="--username ${SVN_U} --password ${SVN_P} --no-auth-cache --non-interactive"


cd /data/mobile/resource_publish/rawres/genscenecfg 

svn ${OPTS} up
./gen.erl



echo "生成场景数据成功 (*^__^*) "
